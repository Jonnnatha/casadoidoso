<nav id="sidebarMenu" class="sidebar d-md-block bg-dark text-white collapse" data-simplebar>
<div class="sidebar-inner px-4 pt-3">
<ul class="nav flex-column pt-3 pt-md-0">
<li class="nav-item">
<a href="" class="nav-link d-flex align-items-center">
  <span class="sidebar-icon">
    <img src="<?php echo base_url('public/assets/img/favicon/favicon-32x32.png')?>" height="20" width="20" alt="Volt Logo">
  </span>
  <span class="mt-1 ms-1 sidebar-text">Lar das Velhinhas </span>
</a>
</li>
<li class="nav-item  active ">
<a href="menu" class="nav-link">
  <span class="sidebar-icon"><span class="fas fa-chart-pie"></span></span>
  <span class="sidebar-text">Menu</span>
</a>
</li>

<li role="separator" class="dropdown-divider mt-4 mb-3 border-black"></li>

</ul>
</div>
</nav>
